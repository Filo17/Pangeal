using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using EasyUI.PickerWheelUI;
using UnityEngine.UI;

public class giraLaRuotaa : MonoBehaviour
{
    [SerializeField] private Button Btn;
    [SerializeField] private PickerWheel pickerWheel;
    [SerializeField] private Text SpinText;
    // Start is called before the first frame update
    private void Start()
    {
        Btn.onClick.AddListener(() =>
        {
            SpinText.text = "Spinning";
            pickerWheel.Spin();
        });
    }
    /*public void OnButtonClick()
    {
        SpinText.text = "Spinning";
        Ruota.Spin();
    }
    */
}
