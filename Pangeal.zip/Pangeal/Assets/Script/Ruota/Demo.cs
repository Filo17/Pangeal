using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using EasyUI.PickerWheelUI;
using UnityEngine.UI;
public class Demo : MonoBehaviour
{
    [SerializeField] private Button Btn;
    [SerializeField] private PickerWheel pickerWheel;
    [SerializeField] private Text SpinText;
    [SerializeField] private Button SnakeBtn;
    [SerializeField] private Button FlappyBtn;
    [SerializeField] private Button PongBtn;
    [SerializeField] private ParticleSystem Confetti;
    // Start is called before the first frame update
    private void Start()
    {
        Btn.onClick.AddListener(() =>
        {
            Btn.interactable = false;
            SpinText.text = "Girando...";
            pickerWheel.OnSpinStart(() =>{ Debug.Log("Spin started"); });

            pickerWheel.OnSpinEnd(WheelPiece =>{
                Debug.Log("Spin End:\n Label: " + WheelPiece.Label + ", Amount: " + WheelPiece.Amount);
                Btn.interactable = true;
                SpinText.text = "GIRA";
                if ( WheelPiece.Label == "PONG")
                {
                    PongBtn.Select();
                    Confetti.transform.position = new Vector3(4.5f, 3, 0);
                    Confetti.Play();
                }
                else if (WheelPiece.Label == "SNAKE")
                {
                    SnakeBtn.Select();
                    Confetti.transform.position = new Vector3(-4.5f, 3, 0);
                    Confetti.Play();
                }
                else if (WheelPiece.Label == "FLAPPY BIRD")
                {
                    FlappyBtn.Select();
                    Confetti.transform.position = new Vector3(0, 3, 0);
                    Confetti.Play();
                }
            });
            pickerWheel.Spin();
        });
    }

    private void Update()
    {
        
    }
}
