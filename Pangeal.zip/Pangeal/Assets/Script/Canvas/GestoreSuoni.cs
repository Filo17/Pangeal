using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class GestoreSuoni : MonoBehaviour
{
    public AudioSource BackgroundMusic;
    public AudioSource saltoSFX;
    public AudioSource puntoSFX;
    public AudioSource MorteSFX;

    private void Start()
    {
        if(BackgroundMusic != null)
        {
            BackgroundMusic.Play();
        }
        
    }
    public void Salto()
    {
        saltoSFX.Play();
    }
    public void Punto()
    {
        puntoSFX.Play();
    }
    public void Morte()
    {
        MorteSFX.Play();
    }
    public void Esci()
    {
        Time.timeScale = 1;
        SceneManager.LoadScene("Menu");
    }

}
