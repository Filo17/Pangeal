using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GestoreScene : MonoBehaviour
{
    public void ApriSnake()
    {
        SceneManager.LoadScene("Snake");
    }
    public void ApriPongMultiPlayer()
    {
        SceneManager.LoadScene("PongMP");
    }
    public void ApriFlappyBird()
    {
        SceneManager.LoadScene("FlappyBird");
    }
    public void TornaAlMenu()
    {
        SceneManager.LoadScene("Menu");
        Time.timeScale = 1;
        Time.fixedDeltaTime = 0.02f;
    }
    public void ChiudiApp()
    {
        Application.Quit();
    }
}
