using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class collisionF : MonoBehaviour
{
    void OnTriggerEnter2D (Collider2D hitInfo) {
        if (hitInfo.name == "tubo")
        {
            string wallName = transform.name;
            gameManeger.Score(wallName);
            hitInfo.gameObject.SendMessage("Restart", 1.0f, SendMessageOptions.RequireReceiver);
        }
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
