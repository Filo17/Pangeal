using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class MovingObject : MonoBehaviour
{
    [SerializeField] private float _speed=0.65f;
    [SerializeField] public float _xBound=-10;
    [SerializeField] private GameObject _pipe;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        this.transform.position -= Vector3.right * _speed * Time.deltaTime;
        if(_xBound==this.transform.position.x)
        {
            Destroy(_pipe);
        }
        
    }
}
