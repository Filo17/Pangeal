
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class spawner : MonoBehaviour
{
    [SerializeField] private float _maxTime = 5f;
    [SerializeField] private float heightRange = 0.45f;
    [SerializeField] private GameObject _pipe;
    [SerializeField] public Transform prova;
    [SerializeField] private float timer;
    [SerializeField] private Vector3 startPosition;
    public float HeightRange { get => heightRange; set => heightRange = value; }

    void Start()
    {
        startPosition = transform.position;
        //SpawnPipe();
        timer=_maxTime;
    }

    // Update is called once per frame
    void Update()
    {
        timer -= Time.deltaTime;
        if (timer <= 0)
        {
            SpawnPipe();
            timer = _maxTime;
        }
    }
    private void SpawnPipe()
    {
        float spawnPosY = Random.Range(-heightRange, heightRange);
        Vector3 spawnPos = new Vector3(9, spawnPosY, 0);
        GameObject pipe = Instantiate(_pipe,startPosition+spawnPos, Quaternion.identity);
    }
}
