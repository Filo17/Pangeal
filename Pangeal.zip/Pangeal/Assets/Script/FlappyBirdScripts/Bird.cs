using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class Bird : MonoBehaviour
{
    [SerializeField] private KeyCode su=KeyCode.W;
    [SerializeField] private float velocita=5.0f;
    private Rigidbody2D rb2d;
    [SerializeField] private float limiteY=3.25f;
    public static event UnityAction OnDeath;

    private void OnCollisionEnter2D()
    {
        OnDeath?.Invoke();

        Time.timeScale = 0f;
    }
    // Start is called before the first frame update
    void Start()
    {
        Time.timeScale = 1f;
        rb2d=GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
         var vel =rb2d.velocity;
            if(Input.GetKey(su))
            {
                vel.y = velocita;
            }
            else {
                vel.y = 0;
            }
            rb2d.velocity = vel;

            var pos = transform.position;
            if (pos.y > limiteY) {
                pos.y = limiteY;
            }
            else if (pos.y < -limiteY) {
                pos.y = -limiteY;
            }
            transform.position = pos;
    }
    
    
}
