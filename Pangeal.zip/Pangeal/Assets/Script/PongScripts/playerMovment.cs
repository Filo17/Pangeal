using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerMovment : MonoBehaviour
{
    public KeyCode su=KeyCode.W;
    public KeyCode giu=KeyCode.S;
    public float velocita=10.0f;
    public float limiteY=2.25f;
    private Rigidbody2D rb2d;
    
    // Start is called before the first frame update
    void Start()
    {
        rb2d=GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
            var vel =rb2d.velocity;
            if(Input.GetKey(su))
            {
                vel.y = velocita;
            }
            else if (Input.GetKey(giu)) {
            vel.y = -velocita;
        }
            else {
                vel.y = 0;
            }
            rb2d.velocity = vel;

            var pos = transform.position;
            if (pos.y > limiteY) {
                pos.y = limiteY;
            }
            else if (pos.y < -limiteY) {
                pos.y = -limiteY;
            }
            transform.position = pos;
    }
}