using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using  UnityEngine.SceneManagement;

public class gameManeger : MonoBehaviour
{
    public static int PlayerScore1=0;
    public static int PlayerScore2 = 0;
    //variabili per la grafica
    public GUISkin layout;
    GameObject theBall;
    public BallMovment obj = new BallMovment();
    // Start is called before the first frame update
    void Start()
    {
        theBall = GameObject.FindGameObjectWithTag("Ball");
        if(SceneManager.GetActiveScene().name== "singlePlayer")
        {
            PlayerScore1=3;
        }
    }
    public static void Score (string wallID) 
    {
        if(SceneManager.GetActiveScene().name== "singlePlayer" && wallID=="left_wall ")//nome scena
        {
            PlayerScore1--;
        }
       else if (wallID == "right_wall")//wallID= nome del muro
        {
            PlayerScore1++;
        } 
        else
        {
            PlayerScore2++;
        }
    }
    void OnGUI () 
    {
        //Scene scene = new Scene();
        //serve per far vedere il punteggio e il tasto reset
        GUI.skin = layout;
        if(SceneManager.GetActiveScene().name== "singlePlayer")
        {
            GUI.Label(new Rect(Screen.width / 2 - 150 - 12, 20, 100, 100), "" + PlayerScore1);
        }
        else
        {
            GUI.Label(new Rect(Screen.width / 2 - 150 - 12, 20, 100, 100), "" + PlayerScore1);
            GUI.Label(new Rect(Screen.width / 2 + 150 + 12, 20, 100, 100), "" + PlayerScore2);
        }
        
        if (GUI.Button(new Rect(Screen.width / 2 - 60, 35, 120, 53), "RESTART"))
        {
            if(SceneManager.GetActiveScene().name== "singlePlayer")
            {
                PlayerScore1= 3;
                theBall.GetComponent<BallMovment>().Restart();
            
            theBall.SendMessage("Restart", 0.5f, SendMessageOptions.RequireReceiver);
            }
            else
            {
                PlayerScore1 = 0;
                PlayerScore2 = 0;
                theBall.GetComponent<BallMovment>().Restart();
                theBall.SendMessage("Restart", 0.5f, SendMessageOptions.RequireReceiver);
            }
        }
        
        if (SceneManager.GetActiveScene().name== "singlePlayer" && PlayerScore1==0)
        {

            GUI.Label(new Rect(Screen.width / 2 - 150, 200, 2000, 1000), "You have loose");
            theBall.SendMessage("Resetpalla", null, SendMessageOptions.RequireReceiver);
            
        }
        
        else if (PlayerScore1 == 5)
        {
            GUI.Label(new Rect(Screen.width / 2 - 150, 200, 2000, 1000), "PLAYER ONE WINS");
            theBall.SendMessage("Resetpalla", null, SendMessageOptions.RequireReceiver);
        } else if (PlayerScore2 == 5)
        {
            GUI.Label(new Rect(Screen.width / 2 - 150, 200, 2000, 1000), "PLAYER TWO WINS");
            theBall.SendMessage("Resetpalla", null, SendMessageOptions.RequireReceiver);
        }
    } 
}
