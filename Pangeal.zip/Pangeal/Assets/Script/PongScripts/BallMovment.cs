using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using  UnityEngine.SceneManagement;

public class BallMovment : MonoBehaviour
{
    private Rigidbody2D rb2d;
    public void inizio()
    {
        //serve per far andare la palla a destra o a sinistra
        float rand = Random.Range(0, 2);
        
        if(rand < 1 || SceneManager.GetActiveScene().name== "singlePlayer"){
            
            Vector2 vel;
            vel.x = rb2d.velocity.x;
            vel.y = 150;
            
            rb2d.AddForce(new Vector2(150, -150));// vettrore forza
           
        } else {
            
            Vector2 vel;
            vel.x = rb2d.velocity.x;
            vel.y = 150;
            
            rb2d.AddForce(new Vector2(-150, -150));
        }
    }
    public void Resetpalla(){
        //quando vinci riporta la palla al centro
        rb2d.velocity = Vector2.zero;
        transform.position = Vector2.zero; // transorm position serve per cambiare posizione, Vector2.zero == posizione(0,0)
    }
    public void Restart()
    {
        //quando ristarti il gioco
        Resetpalla();
        Invoke("inizio", 0); //se cambi il numero ti rimbalza per n volte per terra
    }
    void collisionePlayer (Collision2D coll) 
    {
        if(coll.collider.CompareTag("Player")){
            Vector2 vel;
            vel.x = rb2d.velocity.x;
            vel.y = (rb2d.velocity.y / 3) + (coll.collider.attachedRigidbody.velocity.y / 4);
            rb2d.velocity = vel;
        }
    }
    // Start is called before the first frame update
    void Start()
    {
        rb2d = GetComponent<Rigidbody2D>();
        //aspetta 2 secondi prima di far andare la palla
        Invoke("inizio", 0);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
