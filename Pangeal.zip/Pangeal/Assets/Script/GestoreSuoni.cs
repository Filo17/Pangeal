using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GestoreSuoni : MonoBehaviour
{
    public AudioSource BackgroundMusic;

    private void Start()
    {
        BackgroundMusic.Play();
    }
}
