using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ciboRandom : MonoBehaviour
{

    public BoxCollider2D areaCibo;
    public AudioSource ciboSFX;
    public void PosizioneRandomica()
    {
        Bounds limite = areaCibo.bounds;

        float x = Random.Range(limite.min.x, limite.max.x);
        float y = Random.Range(limite.min.y, limite.max.y);

        this.transform.position = new Vector3(Mathf.Round(x),Mathf.Round(y), 0);
    }
    private void OnTriggerEnter2D(Collider2D other)
    {   
        if (other.tag == "Player")
        {
            ciboSFX.Play();
            PosizioneRandomica();
            Punteggio.AumentaScore();
        }        
    }

}
