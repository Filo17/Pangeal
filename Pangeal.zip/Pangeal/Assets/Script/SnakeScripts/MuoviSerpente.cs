using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MuoviSerpente : MonoBehaviour
{
    //muoversi con le freccie e wasd
    //non poter andare indietro col serpente
    //suono per quando mangi la mela o muori
    private Vector2 _Direzione = Vector2.right;
    private List<Transform> _Segmenti;
    public Transform SegmentoPrefab;
    private int grandezzaIniziale = 2;
    public static bool isAlive = true;
    public GameObject gestorePunti;
    public GameObject PausaMenu;
    public Text PunteggioFinale;
    public AudioSource MorteSFX;
    public AudioSource BGMusic;

    private void Start()
    {
        Time.timeScale = 1;
        Time.fixedDeltaTime = 0.1f;
        BGMusic.Play();
        isAlive = true;
        PausaMenu.SetActive(false);
        _Segmenti = new List<Transform>();
        _Segmenti.Add(this.transform);
        for(int i = 0; i < grandezzaIniziale; i++)
        {
            Cresci();
        }

    }
    private void OnTriggerEnter2D(Collider2D other)
    {
        if(other.tag == "Mela")
        {
            Cresci();
        }
        else if (other.tag == "Segmento" || other.tag == "Finish")
        {
            Gameover();
            MorteSFX.Play();
        }

    }

    // Update is called once per frame
    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.W))
        {
            if (_Direzione != Vector2.down)
            {
                Invoke ("VaiSu", 0.08f);
            }
        }    
        if (Input.GetKeyDown(KeyCode.D))
        {
            if (_Direzione != Vector2.left)
            {
                Invoke("VaiADestra", 0.08f);
            }
        }
        if (Input.GetKeyDown(KeyCode.S))
        {
            if (_Direzione != Vector2.up)
            {
                Invoke("VaiGiu", 0.08f);
            }
        }
        if (Input.GetKeyDown(KeyCode.A))
        {
            if (_Direzione != Vector2.right)
            {
                Invoke("VaiASinistra", 0.08f);
            }
        }
    } //prende in input la direzione

    private void FixedUpdate() //si aggiorna ad ogni frame, velocit� modificabile nelle impostazioni del progetto
    {
        for(int i = _Segmenti.Count-1; i > 0; i--)
        {
            _Segmenti[i].position = _Segmenti[i - 1].position;
        }
        if (isAlive)
        {
            transform.position = new Vector3(
            Mathf.Round(transform.position.x) + _Direzione.x,
            Mathf.Round(transform.position.y) + _Direzione.y,
            0.0f);
        }
        
    }
    private void Cresci()
    {
        Transform segmento = Instantiate(SegmentoPrefab);
        segmento.position = _Segmenti[_Segmenti.Count - 1].position;
        _Segmenti.Add(segmento);
    } //aggiunge un segmento
    private void Gameover()
    {
        Time.timeScale = 0;
        PunteggioFinale.text = "Score: " + Punteggio.Score;
        isAlive = false;
        gestorePunti.SetActive(false);
        PausaMenu.SetActive(true);
        BGMusic.Stop();
    }

    private void VaiADestra()
    {
        _Direzione = Vector2.right;
    }
    private void VaiASinistra()
    {
        _Direzione = Vector2.left;
    }
    private void VaiGiu()
    {
        _Direzione = Vector2.down;
    }
    private void VaiSu()
    {
        _Direzione = Vector2.up;
    }
}
